/**
 * AuthApp.jsx — Single-file Auth System
 * Screens exactly as per blueprint:
 *   Screen 1 (Login):        Photo · Username · Password · Login button
 *   Screen 2 (Registration): Photo · First Name · Last Name · Email · Phone · Country · Additional Info · Register button
 *
 * Stack: React frontend · in-memory SQLite-style DB (swap DB layer for better-sqlite3 + Express)
 */

import { useState, useEffect } from "react";

// ─────────────────────────────────────────────────────────────────
// DATABASE LAYER
// Replace this block with better-sqlite3 API calls in production:
//   const Database = require('better-sqlite3')
//   const db = new Database('procurement.db')
// ─────────────────────────────────────────────────────────────────
const DB = (() => {
  let users = JSON.parse(localStorage.getItem("px_users") || "[]");
  let resets = {};
  const persist = () => localStorage.setItem("px_users", JSON.stringify(users));
  const hash = (p) => btoa(p + "_salt_v1");
  const verify = (p, h) => hash(p) === h;
  const sanitize = ({ password_hash, ...u }) => u;

  const api = {
    // INSERT INTO users
    create({ firstName, lastName, email, phone, country, additionalInfo, role, password, photo }) {
      if (users.find((u) => u.email === email.toLowerCase()))
        return { error: "Email already registered" };
      const u = {
        id: crypto.randomUUID(),
        firstName, lastName,
        email: email.toLowerCase(),
        phone, country,
        additionalInfo: additionalInfo || "",
        role: role || "",
        password_hash: hash(password),
        photo: photo || null,
        createdAt: new Date().toISOString(),
      };
      users.push(u);
      persist();
      return { user: sanitize(u) };
    },

    // SELECT + verify
    login(username, password) {
      const u = users.find((u) => u.email === username.toLowerCase());
      if (!u) return { error: "No account found" };
      if (!verify(password, u.password_hash)) return { error: "Incorrect password" };
      const token = btoa(JSON.stringify({ uid: u.id, exp: Date.now() + 3600000 }));
      return { token, user: sanitize(u) };
    },

    verifyToken(t) {
      try {
        const p = JSON.parse(atob(t));
        if (p.exp < Date.now()) return null;
        const u = users.find((u) => u.id === p.uid);
        return u ? sanitize(u) : null;
      } catch { return null; }
    },

    generateResetToken(email) {
      const u = users.find((u) => u.email === email.toLowerCase());
      if (!u) return { error: "No account found" };
      const tok = Math.random().toString(36).slice(2, 10).toUpperCase();
      resets[email.toLowerCase()] = { tok, exp: Date.now() + 600000 };
      return { message: `Reset token: ${tok}  (valid 10 min)` };
    },

    resetPassword(email, tok, newPwd) {
      const e = email.toLowerCase();
      const entry = resets[e];
      if (!entry || entry.tok !== tok.toUpperCase() || entry.exp < Date.now())
        return { error: "Invalid or expired token" };
      const u = users.find((u) => u.email === e);
      if (!u) return { error: "User not found" };
      u.password_hash = hash(newPwd);
      delete resets[e];
      persist();
      return { ok: true };
    },

    seed() {
      if (!users.length)
        this.create({ firstName: "Arjun", lastName: "Mehta", email: "admin@demo.com", phone: "9876543210", country: "India", additionalInfo: "Procurement Head", password: "Admin@123" });
    },
  };
  return api;
})();

DB.seed();

// ─────────────────────────────────────────────────────────────────
// VENDOR STORE  (in-memory, localStorage-backed)
// ─────────────────────────────────────────────────────────────────
const VendorDB = (() => {
  const KEY = "px_vendors";
  let vendors = JSON.parse(localStorage.getItem(KEY) || "[]");
  const persist = () => localStorage.setItem(KEY, JSON.stringify(vendors));

  const api = {
    all: () => vendors,
    add(v) {
      const rec = { id: crypto.randomUUID(), ...v, createdAt: new Date().toISOString() };
      vendors.push(rec); persist(); return rec;
    },
    seed() {
      if (!vendors.length) {
        api.add({ name: "Infra Supplies Pvt Ltd", category: "Construction", gst: "22A@BCSM*0",  contact: "412 #vendor", status: "Active"  });
        api.add({ name: "Tech Core LTD",          category: "IT",           gst: "22A@BCSM2",   contact: "412 #vendor", status: "Active"  });
        api.add({ name: "Fleeting Transport",      category: "Logistics",    gst: "22A@BCSM3bc", contact: "—",           status: "Pending" });
      }
    },
  };
  return api;
})();
VendorDB.seed();

// ─────────────────────────────────────────────────────────────────
// SESSION MANAGER  (token stored in localStorage; expiry = 1 hour)
// ─────────────────────────────────────────────────────────────────
const Session = {
  save: (t) => localStorage.setItem("px_token", t),
  get: () => localStorage.getItem("px_token"),
  clear: () => localStorage.removeItem("px_token"),
  currentUser: () => { const t = Session.get(); return t ? DB.verifyToken(t) : null; },
};

// ─────────────────────────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────────────────────────
const V = {
  required: (v, label) => v.trim() ? "" : `${label} is required`,
  email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? "" : "Enter a valid email",
  password: (v) =>
    v.length < 8 ? "Min 8 characters" :
    !/[A-Z]/.test(v) ? "Need at least 1 uppercase letter" :
    !/[0-9]/.test(v) ? "Need at least 1 number" : "",
  phone: (v) => /^\d{10}$/.test(v) ? "" : "Enter a valid 10-digit phone number",
};

// ─────────────────────────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #0e0f14; --surface: #161820; --surface2: #1e2028;
    --border: rgba(255,255,255,0.09); --text: #eef0f6; --muted: #7a8396;
    --accent: #63b3ed; --danger: #fc8181; --success: #68d391;
  }
  body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; min-height: 100vh; }
  .app { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem 1rem; }

  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 18px; padding: 2rem; width: 300px; }
  .card-wide { width: 380px; }
  .screen-label { font-family: 'Syne', sans-serif; font-size: 12px; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 1.5rem; padding-bottom: .75rem; border-bottom: 1px solid var(--border); }

  /* Photo circle — matches blueprint center circle */
  .photo-circle { width: 80px; height: 80px; border-radius: 50%; border: 2px solid var(--border); background: var(--surface2); display: flex; align-items: center; justify-content: center; margin: 0 auto .5rem; cursor: pointer; overflow: hidden; transition: border-color .2s; }
  .photo-circle:hover { border-color: var(--accent); }
  .photo-circle img { width: 100%; height: 100%; object-fit: cover; }
  .photo-label { font-size: 12px; color: var(--muted); text-align: center; margin-bottom: 1.5rem; }

  /* Fields */
  .field { margin-bottom: .9rem; }
  .field input, .field textarea { width: 100%; background: var(--surface2); border: 1px solid var(--border); border-radius: 8px; padding: .65rem .9rem; color: var(--text); font-size: 13px; font-family: 'DM Sans', sans-serif; outline: none; transition: border-color .2s; resize: none; }
  .field input:focus, .field textarea:focus { border-color: rgba(99,179,237,.5); }
  .field input.err { border-color: var(--danger); }
  .field input::placeholder, .field textarea::placeholder { color: var(--muted); }
  .field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .field-err { font-size: 11px; color: var(--danger); margin-top: 3px; }

  /* Password wrapper */
  .pwrap { position: relative; }
  .pwrap input { padding-right: 2.2rem; }
  .eye { position: absolute; right: .65rem; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: var(--muted); font-size: 13px; padding: 0; line-height: 1; }

  /* Buttons */
  .btn { width: 100%; padding: .7rem; border: none; border-radius: 8px; font-family: 'Syne', sans-serif; font-size: 13px; font-weight: 700; cursor: pointer; transition: opacity .15s, transform .1s; letter-spacing: .3px; margin-top: .5rem; }
  .btn:active { transform: scale(.98); }
  .btn:disabled { opacity: .5; cursor: not-allowed; }
  .btn-login { background: linear-gradient(135deg, #63b3ed, #b794f4); color: #0e0f14; }
  .btn-register { background: linear-gradient(135deg, #68d391, #63b3ed); color: #0e0f14; }
  .btn-ghost { background: transparent; border: 1px solid var(--border); color: var(--text); }

  /* Alerts */
  .alert { padding: .6rem .85rem; border-radius: 7px; font-size: 12px; margin-bottom: .9rem; display: flex; gap: 6px; }
  .alert-error { background: rgba(252,129,129,.1); border: 1px solid rgba(252,129,129,.2); color: var(--danger); }
  .alert-success { background: rgba(104,211,145,.1); border: 1px solid rgba(104,211,145,.2); color: var(--success); }
  .alert-info { background: rgba(99,179,237,.1); border: 1px solid rgba(99,179,237,.15); color: var(--accent); font-size: 11px; }

  .link { background: none; border: none; color: var(--accent); font-size: 12px; cursor: pointer; padding: 0; font-family: 'DM Sans', sans-serif; text-decoration: underline; text-underline-offset: 2px; }
  .switch { text-align: center; font-size: 12px; color: var(--muted); margin-top: 1rem; }

  /* ── Main Landing (Screen 3) ── */
  .ml-wrap { display: flex; flex-direction: column; width: 100vw; min-height: 100vh; background: var(--bg); }

  /* top bar */
  .ml-topbar { display: flex; align-items: center; justify-content: space-between; padding: .7rem 1.4rem; background: var(--surface); border-bottom: 1px solid var(--border); flex-shrink: 0; }
  .ml-brand { font-family: 'Syne', sans-serif; font-size: 15px; font-weight: 800; color: var(--text); }
  .ml-user-pill { background: #6c3fc5; border-radius: 999px; padding: .35rem .9rem; font-size: 12px; font-weight: 600; color: #fff; }
  .ml-avatar-circle { width: 32px; height: 32px; border-radius: 50%; background: var(--surface2); border: 2px solid var(--border); overflow: hidden; display: flex; align-items: center; justify-content: center; font-size: 13px; flex-shrink: 0; cursor: pointer; }
  .ml-avatar-circle img { width: 100%; height: 100%; object-fit: cover; }

  /* body = sidebar + content */
  .ml-body { display: flex; flex: 1; overflow: hidden; }

  /* sidebar */
  .ml-sidebar { width: 200px; flex-shrink: 0; background: var(--surface); border-right: 1px solid var(--border); padding: 1rem 0; display: flex; flex-direction: column; gap: 2px; }
  .ml-nav-item { padding: .6rem 1.2rem; font-size: 13px; color: var(--muted); cursor: pointer; border-radius: 6px; margin: 0 .5rem; transition: background .15s, color .15s; }
  .ml-nav-item:hover { background: var(--surface2); color: var(--text); }
  .ml-nav-item.active { background: #1a4731; color: #68d391; font-weight: 600; }

  /* main content */
  .ml-content { flex: 1; padding: 1.8rem 2rem; overflow-y: auto; }
  .ml-page-title { font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; margin-bottom: .25rem; }
  .ml-page-sub { font-size: 13px; color: var(--muted); margin-bottom: 1.5rem; }

  /* stat cards */
  .ml-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.8rem; }
  .ml-stat { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 1rem 1.2rem; }
  .ml-stat-val { font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; }
  .ml-stat-lbl { font-size: 11px; color: var(--muted); margin-top: 4px; }

  /* bottom section: table + chart side by side */
  .ml-bottom { display: grid; grid-template-columns: 1fr auto; gap: 1.5rem; margin-bottom: 1.8rem; }
  .ml-table-box { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 1rem; }
  .ml-table-title { font-size: 12px; color: var(--muted); font-weight: 600; margin-bottom: .75rem; }
  .ml-table { width: 100%; border-collapse: collapse; font-size: 12px; }
  .ml-table th { text-align: left; color: var(--muted); padding: .3rem .5rem; border-bottom: 1px solid var(--border); font-weight: 500; }
  .ml-table td { padding: .4rem .5rem; border-bottom: 1px solid var(--border); }
  .ml-table tr:last-child td { border-bottom: none; }
  .ml-status { display: inline-block; padding: 1px 7px; border-radius: 999px; font-size: 11px; }
  .ml-status.approved { background: rgba(104,211,145,.15); color: #68d391; }
  .ml-status.pending  { background: rgba(99,179,237,.15);  color: #63b3ed; }
  .ml-status.draft    { background: rgba(122,131,150,.15); color: var(--muted); }

  /* chart placeholder */
  .ml-chart-box { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 1rem; width: 180px; flex-shrink: 0; }
  .ml-chart-title { font-size: 11px; color: var(--muted); margin-bottom: .6rem; }
  .ml-chart-img { width: 100%; height: 120px; border-radius: 8px; background: var(--surface2); display: flex; align-items: center; justify-content: center; }

  /* divider */
  .ml-divider { border: none; border-top: 1px solid var(--border); margin: .5rem 0 1.2rem; }

  /* action buttons */
  .ml-actions { display: flex; gap: .75rem; }
  .ml-action-btn { padding: .5rem 1.1rem; border: 1px solid var(--border); border-radius: 8px; background: transparent; color: var(--text); font-size: 12px; font-family: 'DM Sans', sans-serif; cursor: pointer; transition: border-color .15s, background .15s; }
  .ml-action-btn:hover { border-color: var(--accent); background: rgba(99,179,237,.07); }

  /* ── Vendors Page ── */
  .vp-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: .4rem; }
  .vp-sub { font-size: 12px; color: var(--muted); margin-bottom: 1.2rem; }
  .vp-search { width: 100%; background: var(--surface2); border: 1px solid var(--border); border-radius: 8px; padding: .6rem .9rem; color: var(--text); font-size: 13px; font-family: 'DM Sans', sans-serif; outline: none; margin-bottom: 1rem; }
  .vp-search:focus { border-color: rgba(99,179,237,.5); }
  .vp-search::placeholder { color: var(--muted); }
  .vp-tabs { display: flex; gap: .5rem; margin-bottom: 1rem; }
  .vp-tab { padding: .3rem .8rem; border-radius: 6px; font-size: 12px; cursor: pointer; border: 1px solid var(--border); background: transparent; color: var(--muted); transition: all .15s; }
  .vp-tab.active { background: #1a4731; color: #68d391; border-color: transparent; font-weight: 600; }
  .vp-tab:hover:not(.active) { background: var(--surface2); color: var(--text); }
  .vp-add-btn { padding: .4rem .9rem; border: 1px solid var(--accent); border-radius: 8px; background: transparent; color: var(--accent); font-size: 12px; font-family: 'DM Sans', sans-serif; cursor: pointer; transition: background .15s; white-space: nowrap; }
  .vp-add-btn:hover { background: rgba(99,179,237,.1); }
  .vp-table-wrap { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; }
  .vp-table { width: 100%; border-collapse: collapse; font-size: 12px; }
  .vp-table th { text-align: left; color: var(--muted); padding: .55rem .8rem; border-bottom: 1px solid var(--border); font-weight: 500; background: var(--surface); }
  .vp-table td { padding: .55rem .8rem; border-bottom: 1px solid var(--border); vertical-align: middle; }
  .vp-table tr:last-child td { border-bottom: none; }
  .vp-table tr:hover td { background: rgba(255,255,255,.02); }
  .vp-badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; }
  .vp-badge.active  { background: rgba(104,211,145,.15); color: #68d391; }
  .vp-badge.pending { background: rgba(99,179,237,.15);  color: #63b3ed; }
  .vp-badge.blocked { background: rgba(252,129,129,.15); color: #fc8181; }
  .vp-view-btn { padding: 2px 10px; border: 1px solid var(--border); border-radius: 6px; background: transparent; color: var(--text); font-size: 11px; cursor: pointer; transition: border-color .15s; }
  .vp-view-btn:hover { border-color: var(--accent); color: var(--accent); }

  /* ── RFQ Page ── */
  .rfq-wrap { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; }
  .rfq-col { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 1.2rem; }
  .rfq-col-title { font-size: 11px; color: var(--muted); font-weight: 600; margin-bottom: .9rem; text-transform: uppercase; letter-spacing: .8px; }
  .rfq-step-bar { display: flex; align-items: center; gap: .4rem; margin-bottom: 1.2rem; }
  .rfq-step { width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; border: 2px solid var(--border); color: var(--muted); }
  .rfq-step.done { background: #68d391; border-color: #68d391; color: #0e0f14; }
  .rfq-step.current { border-color: #63b3ed; color: #63b3ed; }
  .rfq-step-line { flex: 1; height: 2px; background: var(--border); border-radius: 2px; }
  .rfq-step-line.done { background: #68d391; }
  .rfq-field { margin-bottom: .75rem; }
  .rfq-field label { display: block; font-size: 11px; color: var(--muted); margin-bottom: .3rem; }
  .rfq-field input, .rfq-field textarea, .rfq-field select { width: 100%; background: var(--surface2); border: 1px solid var(--border); border-radius: 7px; padding: .5rem .75rem; color: var(--text); font-size: 12px; font-family: 'DM Sans', sans-serif; outline: none; transition: border-color .2s; resize: none; }
  .rfq-field input:focus, .rfq-field textarea:focus, .rfq-field select:focus { border-color: rgba(99,179,237,.5); }
  .rfq-field input::placeholder, .rfq-field textarea::placeholder { color: var(--muted); }
  .rfq-field select option { background: var(--surface2); }
  .rfq-line-table { width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: .6rem; }
  .rfq-line-table th { text-align: left; color: var(--muted); padding: .25rem .4rem; border-bottom: 1px solid var(--border); font-weight: 500; }
  .rfq-line-table td { padding: .3rem .4rem; border-bottom: 1px solid var(--border); }
  .rfq-line-table tr:last-child td { border-bottom: none; }
  .rfq-vendor-tag { display: flex; align-items: center; justify-content: space-between; background: var(--surface2); border-radius: 6px; padding: .3rem .6rem; font-size: 12px; margin-bottom: .4rem; }
  .rfq-vendor-tag button { background: none; border: none; color: var(--muted); cursor: pointer; font-size: 14px; line-height: 1; padding: 0; }
  .rfq-vendor-tag button:hover { color: var(--danger); }
  .rfq-add-vendor-btn { background: none; border: none; color: var(--accent); font-size: 12px; cursor: pointer; padding: 0; font-family: 'DM Sans', sans-serif; text-decoration: underline; text-underline-offset: 2px; }
  .rfq-drop-zone { border: 1.5px dashed var(--border); border-radius: 8px; padding: 1.5rem; text-align: center; font-size: 12px; color: var(--muted); cursor: pointer; transition: border-color .2s; }
  .rfq-drop-zone:hover { border-color: var(--accent); color: var(--accent); }
  .rfq-btns { display: flex; gap: .6rem; margin-top: .8rem; }
  .rfq-btn { flex: 1; padding: .5rem; border: 1px solid var(--border); border-radius: 7px; background: transparent; color: var(--text); font-size: 12px; font-family: 'DM Sans', sans-serif; cursor: pointer; transition: all .15s; }
  .rfq-btn:hover { border-color: var(--accent); background: rgba(99,179,237,.07); }
  .rfq-btn.primary { background: linear-gradient(135deg, #68d391, #63b3ed); border-color: transparent; color: #0e0f14; font-weight: 600; }
  .rfq-btn.primary:hover { opacity: .9; }
`;

// ─────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────
function Alert({ type, children }) {
  return <div className={`alert alert-${type}`}><span>{type === "error" ? "⚠" : "✓"}</span><span>{children}</span></div>;
}

function PhotoCircle({ preview, onChange }) {
  return (
    <label style={{ display: "block" }}>
      <div className="photo-circle">
        {preview
          ? <img src={preview} alt="profile" />
          : <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ color: "var(--muted)" }}><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>
        }
      </div>
      <div className="photo-label">Photo</div>
      <input type="file" accept="image/*" style={{ display: "none" }} onChange={onChange} />
    </label>
  );
}

// ─────────────────────────────────────────────────────────────────
// SCREEN 1 — LOGIN
// Fields: Photo · Username · Password · Login button
// ─────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin, onSignup, onForgot }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [photo, setPhoto] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handlePhoto = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const reader = new FileReader();
    reader.onload = (ev) => setPhoto(ev.target.result);
    reader.readAsDataURL(f);
  };

  const handleLogin = () => {
    setError("");
    if (!username.trim()) { setError("Username is required"); return; }
    if (!password) { setError("Password is required"); return; }
    setLoading(true);
    setTimeout(() => {
      const res = DB.login(username, password);
      if (res.error) { setError(res.error); setLoading(false); }
      else { Session.save(res.token); onLogin(res.user); }
    }, 500);
  };

  return (
    <div className="card">
      <div className="screen-label">Login Screen  (Screen 1)</div>
      {error && <Alert type="error">{error}</Alert>}

      <PhotoCircle preview={photo} onChange={handlePhoto} />

      <div className="field">
        <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} />
      </div>

      <div className="field">
        <div className="pwrap">
          <input type={showPwd ? "text" : "password"} placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
          <button type="button" className="eye" onClick={() => setShowPwd(s => !s)}>{showPwd ? "🙈" : "👁"}</button>
        </div>
      </div>

      <div style={{ textAlign: "right", marginBottom: ".25rem" }}>
        <button className="link" onClick={onForgot}>Forgot password?</button>
      </div>

      <button className="btn btn-login" disabled={loading} onClick={handleLogin}>
        {loading ? "Logging in…" : "Login"}
      </button>

      <div className="alert alert-info" style={{ marginTop: ".9rem" }}>
        Demo: admin@demo.com / Admin@123
      </div>

      <div className="switch">
        New user? <button className="link" onClick={onSignup}>Register</button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// SCREEN 2 — REGISTRATION
// Fields: Photo · First Name · Last Name · Email Address · Phone Number · Country · Additional Information · Register button
// ─────────────────────────────────────────────────────────────────
function SignupScreen({ onLogin, onLoginSwitch }) {
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phone: "", country: "", additionalInfo: "", role: "" });
  const [photo, setPhoto] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handlePhoto = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const reader = new FileReader();
    reader.onload = (ev) => setPhoto(ev.target.result);
    reader.readAsDataURL(f);
  };

  const handleRegister = () => {
    setError("");
    const errs = [
      V.required(form.firstName, "First name"),
      V.required(form.lastName, "Last name"),
      V.email(form.email),
      V.phone(form.phone),
      V.required(form.country, "Country"),
      V.required(form.role, "Role"),
    ].filter(Boolean);
    if (errs.length) { setError(errs[0]); return; }
    setLoading(true);
    setTimeout(() => {
      // Use a default password derived from email for account creation
      const tempPassword = "Default@123";
      const res = DB.create({ ...form, password: tempPassword, photo });
      if (res.error) { setError(res.error); setLoading(false); }
      else {
        const lr = DB.login(form.email, tempPassword);
        Session.save(lr.token);
        onLogin(lr.user);
      }
    }, 700);
  };

  return (
    <div className="card card-wide">
      <div className="screen-label">Registration Screen  (Screen 2)</div>
      {error && <Alert type="error">{error}</Alert>}

      <PhotoCircle preview={photo} onChange={handlePhoto} />

      {/* First Name + Last Name */}
      <div className="field-row">
        <div className="field"><input type="text" placeholder="First Name" value={form.firstName} onChange={set("firstName")} /></div>
        <div className="field"><input type="text" placeholder="Last Name" value={form.lastName} onChange={set("lastName")} /></div>
      </div>

      {/* Email Address */}
      <div className="field"><input type="email" placeholder="Email Address" value={form.email} onChange={set("email")} /></div>

      {/* Phone Number */}
      <div className="field"><input type="tel" placeholder="Phone Number" value={form.phone} onChange={set("phone")} /></div>

      {/* Country */}
      <div className="field"><input type="text" placeholder="Country" value={form.country} onChange={set("country")} /></div>

      {/* Additional Information */}
      <div className="field">
        <textarea placeholder="Additional Information ...." rows={3} value={form.additionalInfo} onChange={set("additionalInfo")} />
      </div>

      {/* Role */}
      <div className="field">
        <input type="text" placeholder="Role" value={form.role} onChange={set("role")} />
      </div>

      <button className="btn btn-register" disabled={loading} onClick={handleRegister}>
        {loading ? "Registering…" : "Register"}
      </button>

      <div className="switch">
        Have an account? <button className="link" onClick={onLoginSwitch}>Login</button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// FORGOT PASSWORD
// ─────────────────────────────────────────────────────────────────
function ForgotScreen({ onBack }) {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState("");
  const [token, setToken] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [error, setError] = useState("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const sendToken = () => {
    const ee = V.email(email); if (ee) { setError(ee); return; }
    setLoading(true);
    setTimeout(() => {
      const res = DB.generateResetToken(email);
      if (res.error) { setError(res.error); } else { setMsg(res.message); setError(""); setStep(2); }
      setLoading(false);
    }, 500);
  };

  const resetPwd = () => {
    const pe = V.password(newPwd); if (pe) { setError(pe); return; }
    if (!token.trim()) { setError("Enter the reset token"); return; }
    setLoading(true);
    setTimeout(() => {
      const res = DB.resetPassword(email, token, newPwd);
      if (res.error) { setError(res.error); setLoading(false); }
      else { setMsg("Password reset! Redirecting…"); setError(""); setTimeout(onBack, 1800); }
    }, 500);
  };

  return (
    <div className="card">
      <div className="screen-label">Forgot Password</div>
      {error && <Alert type="error">{error}</Alert>}
      {msg && <Alert type="success">{msg}</Alert>}

      {step === 1 ? (
        <>
          <div className="field"><input type="email" placeholder="Email Address" value={email} onChange={e => setEmail(e.target.value)} /></div>
          <button className="btn btn-login" disabled={loading} onClick={sendToken}>{loading ? "Sending…" : "Send Reset Token"}</button>
        </>
      ) : (
        <>
          <div className="field"><input type="text" placeholder="Reset Token" value={token} onChange={e => setToken(e.target.value)} style={{ letterSpacing: "2px", textTransform: "uppercase" }} /></div>
          <div className="field"><input type="password" placeholder="New Password" value={newPwd} onChange={e => setNewPwd(e.target.value)} /></div>
          <button className="btn btn-login" disabled={loading} onClick={resetPwd}>{loading ? "Resetting…" : "Reset Password"}</button>
        </>
      )}
      <div className="switch"><button className="link" onClick={onBack}>← Back to login</button></div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// VENDORS PAGE
// ─────────────────────────────────────────────────────────────────
function VendorsPage() {
  const [search, setSearch]   = useState("");
  const [tab, setTab]         = useState("All");
  const [vendors, setVendors] = useState(VendorDB.all());
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm]       = useState({ name: "", category: "", gst: "", contact: "", status: "Active" });

  const tabCounts = {
    All:     vendors.length,
    Active:  vendors.filter(v => v.status === "Active").length,
    Pending: vendors.filter(v => v.status === "Pending").length,
    Blocked: vendors.filter(v => v.status === "Blocked").length,
  };

  const visible = vendors.filter(v => {
    const matchTab = tab === "All" || v.status === tab;
    const q = search.toLowerCase();
    const matchSearch = !q || v.name.toLowerCase().includes(q) || v.category.toLowerCase().includes(q) || v.gst.toLowerCase().includes(q);
    return matchTab && matchSearch;
  });

  const handleAdd = () => {
    if (!form.name.trim()) return;
    VendorDB.add(form);
    setVendors([...VendorDB.all()]);
    setForm({ name: "", category: "", gst: "", contact: "", status: "Active" });
    setShowAdd(false);
  };

  return (
    <>
      <div className="vp-header">
        <div>
          <div className="ml-page-title">Vendors</div>
          <div className="vp-sub">Manage supplier profiles and registrations</div>
        </div>
        <button className="vp-add-btn" onClick={() => setShowAdd(s => !s)}>+ Add Vendor</button>
      </div>

      {/* Inline add form */}
      {showAdd && (
        <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 10, padding: "1rem", marginBottom: "1rem", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "8px" }}>
          {[["Vendor Name","name"],["Category","category"],["GST No.","gst"],["Contact","contact"]].map(([ph, key]) => (
            <input key={key} className="vp-search" style={{ marginBottom: 0 }} placeholder={ph} value={form[key]} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))} />
          ))}
          <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))} style={{ background: "var(--surface2)", border: "1px solid var(--border)", borderRadius: 8, padding: ".55rem .75rem", color: "var(--text)", fontSize: 12, outline: "none" }}>
            <option>Active</option><option>Pending</option><option>Blocked</option>
          </select>
          <div style={{ display: "flex", gap: "8px", gridColumn: "span 3" }}>
            <button className="vp-add-btn" onClick={handleAdd}>Save</button>
            <button className="vp-add-btn" style={{ borderColor: "var(--border)", color: "var(--muted)" }} onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </div>
      )}

      <input className="vp-search" placeholder="Search bar …  search by name, gst number, category…" value={search} onChange={e => setSearch(e.target.value)} />

      <div className="vp-tabs">
        {Object.entries(tabCounts).map(([label, count]) => (
          <button key={label} className={`vp-tab${tab === label ? " active" : ""}`} onClick={() => setTab(label)}>
            {label} ({count})
          </button>
        ))}
      </div>

      <div className="vp-table-wrap">
        <table className="vp-table">
          <thead>
            <tr>
              <th>Vendor Name</th><th>Category</th><th>GST no.</th><th>contact no.</th><th>Status</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
            {visible.length === 0 && (
              <tr><td colSpan={6} style={{ textAlign: "center", color: "var(--muted)", padding: "1.2rem" }}>No vendors found</td></tr>
            )}
            {visible.map(v => (
              <tr key={v.id}>
                <td>{v.name}</td>
                <td>{v.category}</td>
                <td style={{ fontFamily: "monospace", fontSize: 11 }}>{v.gst}</td>
                <td>{v.contact}</td>
                <td><span className={`vp-badge ${v.status.toLowerCase()}`}>{v.status}</span></td>
                <td><button className="vp-view-btn">View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────
// RFQ PAGE  (Create RFQ's)
// ─────────────────────────────────────────────────────────────────
const INIT_LINE_ITEMS = [
  { item: "Ergonomic chair", qty: 20, unit: "pcs" },
  { item: "Standing desks",  qty: 10, unit: "pcs" },
];

function RFQPage() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ title: "Office Furniture procurement Q2", category: "Furniture", description: "Ergonomic chairs and Standing desks for 2nd floor" });
  const [lineItems] = useState(INIT_LINE_ITEMS);
  const [vendors, setVendors] = useState(["Infra Supplies Pvt Ltd", "Techsavvy LTD"]);
  const [attachments, setAttachments] = useState([]);
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleDrop = e => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer?.files || e.target.files || []);
    setAttachments(a => [...a, ...files.map(f => f.name)]);
  };

  const removeVendor = name => setVendors(v => v.filter(x => x !== name));

  return (
    <>
      <div className="ml-page-title" style={{ marginBottom: ".25rem" }}>Create RFQ's</div>
      <div className="ml-page-sub">new request for quotation</div>

      {/* Step bar */}
      <div className="rfq-step-bar" style={{ maxWidth: 300, marginBottom: "1.4rem" }}>
        <div className={`rfq-step${step >= 1 ? " done" : " current"}`}>1</div>
        <div className={`rfq-step-line${step >= 2 ? " done" : ""}`}/>
        <div className={`rfq-step${step >= 2 ? " done" : step === 2 ? " current" : ""}`} style={step < 2 ? { borderColor: "var(--border)" } : {}}>2</div>
        <div className={`rfq-step-line${step >= 3 ? " done" : ""}`}/>
        <div className={`rfq-step${step >= 3 ? " done" : step === 3 ? " current" : ""}`} style={step < 3 ? { borderColor: "var(--border)" } : {}}>3</div>
      </div>

      <div className="rfq-wrap">
        {/* LEFT COL — RFQ details */}
        <div className="rfq-col">
          <div className="rfq-col-title">RFQ Details</div>

          <div className="rfq-field">
            <label>RFQ's title *</label>
            <input value={form.title} onChange={set("title")} placeholder="RFQ's title" />
          </div>

          <div className="rfq-field">
            <label>Category</label>
            <input value={form.category} onChange={set("category")} placeholder="Category" />
          </div>

          <div className="rfq-field">
            <label>Description</label>
            <textarea rows={3} value={form.description} onChange={set("description")} placeholder="Description…" />
          </div>

          {/* Vendors */}
          <div className="rfq-field">
            <label>Vendors</label>
            {vendors.map(v => (
              <div className="rfq-vendor-tag" key={v}>
                <span>{v}</span>
                <button onClick={() => removeVendor(v)}>×</button>
              </div>
            ))}
            <button className="rfq-add-vendor-btn">+ add vendor</button>
          </div>

          {/* Attachments */}
          <div className="rfq-field">
            <label>Attachments</label>
            <div
              className="rfq-drop-zone"
              onDrop={handleDrop}
              onDragOver={e => e.preventDefault()}
              onClick={() => document.getElementById("rfq-file-input").click()}
            >
              {attachments.length > 0
                ? attachments.join(", ")
                : "Drag & drop files or click to upload"}
            </div>
            <input id="rfq-file-input" type="file" multiple style={{ display: "none" }} onChange={handleDrop} />
          </div>

          <div className="rfq-btns">
            <button className="rfq-btn primary">Save &amp; Send to Vendors</button>
            <button className="rfq-btn">Save as Draft</button>
          </div>
        </div>

        {/* RIGHT COL — Line items */}
        <div className="rfq-col">
          <div className="rfq-col-title">Line Items</div>
          <table className="rfq-line-table">
            <thead>
              <tr><th>Item</th><th>Qty</th><th>Unit</th></tr>
            </thead>
            <tbody>
              {lineItems.map((li, i) => (
                <tr key={i}>
                  <td>{li.item}</td>
                  <td>{li.qty}</td>
                  <td>{li.unit}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="rfq-add-vendor-btn" style={{ fontSize: 11 }}>+ add line item</button>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────
// SCREEN 3 — MAIN LANDING PAGE
// VendorBridge layout: topbar · sidebar · dashboard content
// ─────────────────────────────────────────────────────────────────
const NAV_ITEMS = ["Dashboard", "Vendors", "RFQ's", "Quotations", "Approvals", "Purchase orders", "Invoices", "Reports", "Activity"];

const RECENT_POS = [
  { po: "Po1", vendor: "Infra",          amount: "87000",  status: "Approved" },
  { po: "Po2", vendor: "Tech core",      amount: "190000", status: "Pending"  },
  { po: "Po3", vendor: "OfficeNeed Co",  amount: "34900",  status: "draft"    },
];

function SpendingChart() {
  return (
    <svg viewBox="0 0 140 110" width="140" height="110" style={{ display: "block" }}>
      {/* pie */}
      <circle cx="100" cy="28" r="18" fill="#1e2028" stroke="rgba(255,255,255,.07)" strokeWidth="1"/>
      <path d="M100 10 A18 18 0 0 1 118 28 L100 28 Z" fill="#63b3ed"/>
      <path d="M118 28 A18 18 0 0 1 100 46 L100 28 Z" fill="#68d391"/>
      <path d="M100 46 A18 18 0 1 1 100 10 L100 28 Z" fill="#b794f4"/>
      {/* line chart */}
      <polyline points="10,85 30,70 50,78 70,58 90,65 110,50 130,55" fill="none" stroke="#fc8181" strokeWidth="2" strokeLinejoin="round"/>
      {[10,30,50,70,90,110,130].map((x,i)=>{
        const ys=[85,70,78,58,65,50,55];
        return <circle key={x} cx={x} cy={ys[i]} r="3" fill="#fc8181"/>;
      })}
      {/* bar chart */}
      {[
        {x:10,h:20,c:"#f6ad55"},{x:28,h:32,c:"#f6ad55"},{x:46,h:14,c:"#f6ad55"},
        {x:64,h:26,c:"#f6ad55"},{x:82,h:18,c:"#f6ad55"},
      ].map(b=>(
        <rect key={b.x} x={b.x} y={105-b.h} width="14" height={b.h} rx="2" fill={b.c} opacity=".7"/>
      ))}
    </svg>
  );
}

function MainLanding({ user, onLogout }) {
  const [activeNav, setActiveNav] = useState("Dashboard");
  const initials = ((user.firstName || "")[0] + (user.lastName || "")[0]).toUpperCase();
  const displayName = `${user.firstName} ${user.lastName}`;

  const stats = [
    { val: "12",    lbl: "Active RFQ's"      },
    { val: "5",     lbl: "Pending Approvals" },
    { val: "$ 2.3L", lbl: "PO's this month"  },
    { val: "3",     lbl: "overdue invoices"  },
  ];

  return (
    <div className="ml-wrap">
      {/* ── Top Bar ── */}
      <div className="ml-topbar">
        <span className="ml-brand">VendorBridge</span>
        <span className="ml-user-pill">{displayName}</span>
        <div className="ml-avatar-circle" title="Sign out" onClick={onLogout}>
          {user.photo ? <img src={user.photo} alt="avatar"/> : initials}
        </div>
      </div>

      <div className="ml-body">
        {/* ── Sidebar ── */}
        <nav className="ml-sidebar">
          {NAV_ITEMS.map(item => (
            <div
              key={item}
              className={`ml-nav-item${activeNav === item ? " active" : ""}`}
              onClick={() => setActiveNav(item)}
            >
              – {item}
            </div>
          ))}
        </nav>

        {/* ── Main Content ── */}
        <main className="ml-content">
          {activeNav === "Dashboard" && <>
            <div className="ml-page-title">Dashboard</div>
            <div className="ml-page-sub">Welcome back, {user.role || "Procurement Officer"} – Today's Overview</div>

            {/* Stat cards */}
            <div className="ml-stats">
              {stats.map(s => (
                <div className="ml-stat" key={s.lbl}>
                  <div className="ml-stat-val">{s.val}</div>
                  <div className="ml-stat-lbl">{s.lbl}</div>
                </div>
              ))}
            </div>

            {/* Table + Chart */}
            <div className="ml-bottom">
              <div className="ml-table-box">
                <div className="ml-table-title">Recent Purchase Orders</div>
                <table className="ml-table">
                  <thead>
                    <tr>
                      <th>PO#</th><th>Vendor</th><th>Amount</th><th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {RECENT_POS.map(r => (
                      <tr key={r.po}>
                        <td>{r.po}</td>
                        <td>{r.vendor}</td>
                        <td>{r.amount}</td>
                        <td><span className={`ml-status ${r.status.toLowerCase()}`}>{r.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="ml-chart-box">
                <div className="ml-chart-title">Spending Trends last 6 months</div>
                <div className="ml-chart-img"><SpendingChart /></div>
              </div>
            </div>

            <hr className="ml-divider"/>

            {/* Action buttons */}
            <div className="ml-actions">
              <button className="ml-action-btn" onClick={() => setActiveNav("RFQ's")}>+ new RFQ</button>
              <button className="ml-action-btn" onClick={() => setActiveNav("Vendors")}>Add Vendor</button>
              <button className="ml-action-btn">View Invoices</button>
            </div>
          </>}

          {activeNav === "Vendors" && <VendorsPage />}
          {activeNav === "RFQ's"   && <RFQPage />}

          {!["Dashboard","Vendors","RFQ's"].includes(activeNav) && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "60%", gap: ".5rem" }}>
              <div style={{ fontSize: 36 }}>🚧</div>
              <div className="ml-page-title" style={{ fontSize: 16 }}>{activeNav}</div>
              <div style={{ fontSize: 13, color: "var(--muted)" }}>Coming soon</div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// ROOT APP
// ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("login");
  const [user, setUser] = useState(null);

  useEffect(() => {
    const u = Session.currentUser();
    if (u) { setUser(u); setScreen("main"); }
  }, []);

  const handleLogin = (u) => { setUser(u); setScreen("main"); };
  const handleLogout = () => { Session.clear(); setUser(null); setScreen("login"); };

  return (
    <>
      <style>{css}</style>
      {screen !== "main" && (
        <div className="app">
          {screen === "login"  && <LoginScreen  onLogin={handleLogin} onSignup={() => setScreen("signup")} onForgot={() => setScreen("forgot")} />}
          {screen === "signup" && <SignupScreen  onLogin={handleLogin} onLoginSwitch={() => setScreen("login")} />}
          {screen === "forgot" && <ForgotScreen  onBack={() => setScreen("login")} />}
        </div>
      )}
      {screen === "main" && user && <MainLanding user={user} onLogout={handleLogout} />}
    </>
  );
}
